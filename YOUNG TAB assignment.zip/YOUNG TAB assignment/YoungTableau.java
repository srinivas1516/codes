import java.util.*;

public class YoungTableau {

    public static void insert_element(int[][] young, int i, int j, int key) {
        int x, y, maximum, tp;

        if (young[i][j] < key) {
            System.out.println("The Table is full,insertion Not possible");
            return;
        }
        young[i][j] = key;
        x = i;
        y = j;
        maximum = Integer.MAX_VALUE;

        while ((i > 0 || j > 0) && (maximum > young[i][j])) {

            tp = young[x][y];
            young[x][y] = young[i][j];
            young[i][j] = tp;
            i = x;
            j = y;

            if (i - 1 >= 0 && young[i][j] < young[i - 1][j]) {
                x = i - 1;
                y = j;
            }
            if (j - 1 >= 0 && young[x][y] < young[i][j - 1]) {
                x = i;
                y = j - 1;
            }
            maximum = young[x][y];
        }
    }

    public static int extract_min(int[][] youngT) {
        int x = youngT[0][0];
        youngT[0][0] = Integer.MAX_VALUE;
        youngify(youngT, 0, 0);
        return x;
    }

    public static void youngify(int[][] young_t, int i, int j) {
        int x, y;
        x = i;
        y = j;
        int temp;

        if (i + 1 < 4) {
            if (young_t[i][j] > young_t[i + 1][j]) {
                x = i + 1;
                y = j;
            }
        }
        if (j + 1 < 4) {
            if (young_t[x][y] > young_t[i][j + 1]) {
                x = i;
                y = j + 1;
            }
        }
        if (x != i || y != j) {
            temp = young_t[x][y];
            young_t[x][y] = young_t[i][j];
            young_t[i][j] = temp;
            youngify(young_t, x, y);
        }
    }

    public static void printArray(int arr[][]) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++)
                System.out.print(arr[i][j] + " ");

            System.out.print("\n");
        }
        System.out.print("\n");
    }

    public static boolean searchelement(int[][] young_t, int i, int j, int key) {

        int start_x, start_y;
        start_x = i;
        start_y = j;

        if (i >= 0 && j < 4) {
            if (young_t[i][j] == key) {

                return true;
            } else if (young_t[i][j] < key) {
                return searchelement(young_t, i, j + 1, key);
            } else if (young_t[i][j] > key) {
                return searchelement(young_t, i - 1, j, key);
            } else
                return false;
        } else
            return false;
    }

    public static void sort_Table(int arr[][], int keys[]) {
        for (int key : keys) {
            insert_element(arr, 3, 3, key);
        }
        for (int i = 0; i < keys.length; i++) {
            keys[i] = extract_min(arr);
        }

    }

    public static void main(String[] args) {

        int tableauarr[][] = new int[4][4];
        int keys[] = { 9, 16, 3, 2, 4, 8, 5, 14, 12 }; // from the assignment description

        int keysforsorting[] = { 9, 16, 3, 2, 4, 8, 5, 14, 12, 20, 23, 27, 33, 54, 65, 93 };

        for (int[] row : tableauarr) {
            Arrays.fill(row, Integer.MAX_VALUE);
        }

        for (int key : keys) {
            insert_element(tableauarr, 3, 3, key);
        }

        printArray(tableauarr);

        System.out.println("Minimum value present in the tableau matrix: " + extract_min(tableauarr));

        System.out.println("Key Searched 31 :");
        System.out.println(searchelement(tableauarr, 3, 3, 31) ? "Key present" : "key not present");
        System.out.println("Key Searched 14 :");
        System.out.println(searchelement(tableauarr, 3, 3, 14) ? "Key present" : "key not present");
        for (int[] row : tableauarr) {
            Arrays.fill(row, Integer.MAX_VALUE);
        }

        System.out.println("The Values Before Sorting: ");

        for (int key : keysforsorting) {
            System.out.print(key + " ");
        }
        System.out.println("");
        System.out.println("The Values After Sorting: ");

        sort_Table(tableauarr, keysforsorting);

        for (int key : keysforsorting) {
            System.out.print(key + " ");
        }

    }
}